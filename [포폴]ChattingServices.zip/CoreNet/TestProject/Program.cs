﻿using CoreNet;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using TestProject.CryptTest;

namespace TestProject
{
    class Program
    {
        static void Main(string[] args)
        {
            var tester = new DhCryptTester();
            tester?.DoTest();
            
            Console.ReadKey();
        }
        
    }
}
