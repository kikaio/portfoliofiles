﻿using CoreNet.Utils.Loggers;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreNet.Jobs
{
    //RPC 호출할때 쓰이려나?
    public class WorkerMgr
    {

        public static WorkerMgr Inst { get; } = new WorkerMgr();
        CoreLogger logger = new ConsoleLogger();
        public ConcurrentDictionary<string, Worker> workerDict = new ConcurrentDictionary<string, Worker>();
        private WorkerMgr()
        {
        }

        public void AddWorker(Worker _w)
        {
            if (workerDict.TryAdd(_w.workerName, _w))
                return;
            logger.WriteDebug($"worker[{_w.workerName}] is already exist");
        }

        public Worker GetWorkerByName(string _name)
        {
            var ret = default(Worker);
            if (workerDict.TryGetValue(_name, out ret))
                return ret;
            logger.WriteDebug($"worker[{_name}] is not exist");
            return null;
        }

        public void ShutDown()
        {
            foreach (var ele in workerDict.Values.ToList())
            {
                ele.WorkFinish();
            }
        }
    }
}
