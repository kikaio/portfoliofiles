﻿using CoreChatServer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TcpAsyncServer_TAP.Configs;

namespace TcpAsyncServer_TAP
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                ConfMgr.Init();
                ChatServer server = new ChatServer(ConfMgr.mServerConf.port);
                server.ReadyToStart();
                server.Start();
                while (server.isDown == false)
                {
                    Thread.Sleep(100);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            Console.WriteLine("server is fin, press any key");
            Console.ReadKey();
        }
    }
}
