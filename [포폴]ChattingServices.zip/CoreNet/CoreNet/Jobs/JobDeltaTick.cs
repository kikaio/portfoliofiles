﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreNet.Jobs
{
    public class JobDeltaTick : Job
    {
        //datetime에서 사용하는 tick
        public JobDeltaTick(Action _j, DateTime _sDt, DateTime _eDt, long _deltaTick)
        {
            StartDate = _sDt;
            EndDate = _eDt;
            deltaTick = _deltaTick;
            JobAct = _j;
        }

        public override bool Tick()
        {
            //s~e 기간중 deltaTick 간격마다 job을 수행한다. 
            //단, delta==0일때는 매 Tick호출시마다 job실행.
            if (EndDate < DateTime.UtcNow)
                return false;
            if (StartDate > DateTime.UtcNow)
                return true;
            JobAct?.Invoke();
            if (deltaTick != 0)
                StartDate.AddTicks(deltaTick);
            return true;
        }
    }
}
