﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreNet.Networking
{
    public class RpcMgr
    {
        public static RpcMgr Inst { get; private set; } = new RpcMgr();

        //RPC이름, args 정보, return 이 존재하는지
        public enum RPC_ID
        {
            RPC_WELCOME_REQ,
            RPC_WELCOME_ANS,
        }
        public Dictionary<RPC_ID, Action> NotiRpcDict = new Dictionary<RPC_ID, Action>();
        public Dictionary<RPC_ID, Func<NetStream>> ReqRpcDict = new Dictionary<RPC_ID, Func<NetStream>>();
        public Dictionary<RPC_ID, Func<NetStream>> AnsRpcDict = new Dictionary<RPC_ID, Func<NetStream>>();

    }
}
