﻿using CoreNet.Crypt;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject.CryptTest
{
    public class XorCryptTester : Tester
    {
        public override void DoTest()
        {
            string msg = "tttt";
            string key = "test";

            var dataBytes = new byte[] { 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8, 0x8};
            byte[] keyBytes = new byte[] { 0x8, 0x0, 0x8};

            //var dataBytes = Encoding.UTF8.GetBytes(msg);
            //byte[] keyBytes = Encoding.UTF8.GetBytes(msg);

            var encryptedBytes = CryptHelper.XorEncrypt(dataBytes, keyBytes);
            var recoveredBytes = CryptHelper.XorEncrypt(encryptedBytes, keyBytes);

            RenderBytes(dataBytes, "[dataBytes]");
            RenderBytes(encryptedBytes, "[encryptedBytes]");
            RenderBytes(recoveredBytes, "[recoveredBytes]");
        }

    }
}
