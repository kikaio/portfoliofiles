본 프로젝트는 허영욱의 포트폴리오 용입니다.

해당 프로젝트에 대한 ppt는 아래 링크에서 확인하실 수 있습니다.
https://docs.google.com/presentation/d/1XIiKgJ_W2F1PkbwW1FZ16TJJriw9D5o8F5XWI7djI0s/edit?usp=sharing

해당 프로젝트의 git 주소는 아래와 같습니다.
https://privateProj@dev.azure.com/privateProj/ChattingServices/_git/ChattingServices

mail : gjduddnr5923@naver.com



server 사용법
빌드 후 exe파일을 실행 시킨다.
만약 설정관련 값을 변경 시 configs폴더의 내용을 적용한 후 복사해서 debug폴더 안에 넣어준다.

client 사용법
빌드 후 exe파일을 실행시킨다.
만약 설정관련 값을 변경 시 configs폴더의 내용을 적용한 후 복사하여 debug폴더안에 넣어준다.

exe파일 실행 후 
각 space로 구분된 cmd에 따라서 명령을 수행합니다.
. TEST
 - 해당 명령을 통해 미리 지정된 test용 packet을 server로 전달합니다.
 - server역시 test packet 을 수신 후 지정된 logic을 실행합니다.
. SIGN
 - SIGN IN nickname password
	-> 지정된 DB의 User data를 추가합니다. [단 nickname, password 가 일치할 시]
 - SIGN OUT nickname password
	-> 지정된 DB의 User data를 제거합니다. [단 nickname, password 가 일치할 시]
. LOG
 - LOG IN nickname password
	-> 입력된 닉네임, 비밀번호와 일치하는 유저가 존재할 시 true응답을 수신.
 - LOG OUT nickname password
	-> 입력된 닉네임, 비밀번호와 일치하는 유저가 존재할 시 true응답을 수신.

암호화 
. XOR : packet의 header 값을 난독화 할 때 사용.
. DH : packet의 data부분을 암호화 할 때 사용.
. RSA : server와 client가 DH의 key값을 전달할 시 사용.
. SHA : user의 password를 db에 저장 혹은 저장된 값과 비교시 사용.



DataBase에 관하여
현재 DB에 대한 연결은 local:3360으로 고정되어 있습니다.
사용할 수 있는 Table은 Users 등이 있으며 해당 Table들의 생성 쿼리 역시 프로젝트에 포함되어 있습니다.
기본적인 가입, 탈퇴, 로그인, 로그아웃 기능 활용 시 Users Table을 사용합니다.
