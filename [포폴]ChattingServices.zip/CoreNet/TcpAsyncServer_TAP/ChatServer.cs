﻿using CoreChatServer.DB;
using CoreChatServer.DB.Sets;
using CoreNet;
using CoreNet.Crypt;
using CoreNet.Jobs;
using CoreNet.Networking;
using CoreNet.Servers;
using CoreNet.Sockets;
using CoreNet.Utils.LockHelper;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TcpAsyncCommon_TAP.Packets;
using TcpAsyncServer_TAP.Configs;

namespace CoreChatServer
{
    public class ChatServer : CoreServer
    {
        public ChatServer(int _port = 30000)
            : base("ChatServer", _port)
        {
            shutdownAct = shutdownServer;
        }

        //session 관리는 pkgWorker 내부에서 처리하자.
        Worker pkgWorker = new Worker("pkgWorker", true);
        Worker cmdWorker = new Worker("cmdWorker", true);
        CancellationTokenSource serverDownToken = new CancellationTokenSource();

        protected override void BindAndListen()
        {
            IPEndPoint ep = new IPEndPoint(IPAddress.Any, port);
            listenSock = new CoreTCP();
            var sock = listenSock.Sock;
            sock.NoDelay = true;
            sock.Bind(ep);
            sock.Listen(100);
        }

        public override void ReadyToStart()
        {
            //port 등 config 정보 읽어옴.
            BindAndListen();
            //Config 읽어서 준비하는 부분.
            ReadyWorker();
        }


        private void ReadyWorker()
        {
            Job cmdJob = new JobInfinity(() => {
                if (serverDownToken.IsCancellationRequested)
                    return;
                string cmd = Console.ReadLine();
                if (cmd.ToUpper() == "EXIT")
                {
                    logger.WriteDebugWarn("server shutdown cmd detactive");
                    shutdownAct();
                }
                else
                {
                    //서버의 별도 cmd는 여기서 처리.
                }
            });
            Job pkgJob = new JobInfinity(async () => {
                if (serverDownToken.IsCancellationRequested)
                    return;
                packageQ.Swap();
                while (true)
                {
                    var pkg = default(Package);
                    pkg = packageQ.pop();
                    if (pkg == null)
                        break;
                    else
                        await PackageDispatcherAsync(pkg);
                }
                CheckHeartBeats();
            });


            pkgWorker.PushJob(pkgJob);
            cmdWorker.PushJob(cmdJob);

            WorkerMgr.Inst.AddWorker(pkgWorker);
            WorkerMgr.Inst.AddWorker(cmdWorker);

        }

        public override void Start()
        {
            pkgWorker.WorkStart();
            cmdWorker.WorkStart();
            var tAccept = new Thread(async () => { await AcceptSocket(); });
            tAccept.Start();
            tAccept.Join();
        }

        private async Task AcceptSocket()
        {
            try
            {

                await Task.Factory.StartNew(async () => {
                    try
                    {
                        using (var context = ConfMgr.GetDbContext())
                        {
                            await context.Users.FirstOrDefaultAsync();
                            Console.WriteLine($"context startNew : {DateTime.UtcNow.ToLongTimeString()}");
                        }
                    }
                    catch (Exception e)
                    {
                        logger.Error(e.ToString());
                    }
                }, TaskCreationOptions.None);

                while (serverDownToken.IsCancellationRequested == false)
                {
                    var serverSock = listenSock.Sock;
                    var newSock = await Task<Socket>.Factory.FromAsync(serverSock.BeginAccept(null, null), listenSock.Sock.EndAccept);
                    CoreTCP newClient = new CoreTCP(newSock);
                    long nextId = SessionMgr.Inst.GetNextSessionId();
                    var newSession = new CoreSession(nextId, newClient);
                    if (SessionMgr.Inst.AddSession(newSession) == false)
                    {
                        logger.WriteDebug("Session add is filed");
                        continue;
                    }
                    logger.WriteDebug("New session accepted and add");

                    //welcome packet 전송.
                    await Task.Factory.StartNew(async () =>
                    {
                        var packet = new PacketWelcome();
                        packet.sId = newSession.SessionId;
                        packet.SerialWirte();

                        logger.WriteDebug($"send welcome packet to {packet.sId}");
                        await SendPacketToSession(newSession, packet);
                    });

                    await Task.Factory.StartNew(async () =>
                    {
                        long sid = newSession.SessionId;
                        while (newSession.IsExpireHeartBeat() == false)
                        {
                            var packet = await newSession.OnRecvTAP();
                            if (packet == null)
                            {
                                var delSession = default(CoreSession);
                                SessionMgr.Inst.CloseSession(sid, out delSession);
                                logger.Error($"{sid} is disconnected, recv stopped");
                                break;
                            }
                            else
                            {
                                if (packet.GetHeader() == 0)
                                    packet = new PacketHbCheck_Noti();
                                packageQ.Push(new Package(newSession, packet));
                            }
                        }
                    });

                }
            }
            catch (Exception e)
            {
                logger.Error(e.ToString());
            }
        }

        private void shutdownServer()
        {
            serverDownToken.Cancel();
            logger.WriteDebugWarn("Server Shutdown after 3 minuites");
            //session들에게 전달.
            foreach (var ele in SessionMgr.Inst.ToSessonList())
            {
                SessionMgr.Inst.CloseAllSession();
            }
            Thread.Sleep(1000 * 60 * 3);
            logger.WriteDebugWarn("Server Shutdown And exit this process");
            pkgWorker.WorkFinish();
            cmdWorker.WorkFinish();

            isDown = true;
        }
        
        //update header까지 된 packet을 전송, 오류 처리하는 부분.
        private async Task SendPacketToSession(CoreSession _s, Packet _p)
        {
            if (await _s.OnSendTAP(_p) == false)
            {
                var closed = default(CoreSession);
                if (SessionMgr.Inst.CloseSession(_s.SessionId, out closed))
                {
                    logger.WriteDebugWarn($"{closed.SessionId} is Disconnected and closed");
                }
            }
        }

        protected override void Analizer_Ans(CoreSession _s, Packet _p)
        {
            throw new NotImplementedException("don't use this method in async server");
        }

        protected override void Analizer_Noti(CoreSession _s, Packet _p)
        {
            throw new NotImplementedException("don't use this method in async server");
        }

        protected override void Analizer_Req(CoreSession _s, Packet _p)
        {
            throw new NotImplementedException("don't use this method in async server");
        }

        protected override void Analizer_Test(CoreSession _s, Packet _p)
        {
            throw new NotImplementedException("don't use this method in async server");
        }

        protected override async Task AnalizerAsync_Req(CoreSession _s, Packet _p)
        {
            try
            {
                switch (_p.cType)
                {
                    case Packet.CONTENT_TYPE.CHATTING:
                        {
                            var packet = PacketFactory.Inst.ConvertPacket<PacketChat_Req>(_p);
                            //우선 접속한 session 들에게 모두 전달
                            logger.WriteDebug($"[Broad cast from {packet.sId} at {new DateTime(packet.ticks).ToLongTimeString()}]-{packet.chat}");
                            foreach (var s in SessionMgr.Inst.ToSessonList())
                            {
                                await Task.Run(async () => {
                                    var ans = new PacketChat_Ans(_p.data.bytes.Length);
                                    ans.sId = packet.sId;
                                    ans.chat = packet.chat;
                                    ans.ticks = packet.ticks;
                                    ans.SerialWirte();
                                    await SendPacketToSession(s, ans);
                                });
                            }
                        }
                        break;
                    case Packet.CONTENT_TYPE.SIGN_IN:
                        {
                            var p = PacketFactory.Inst.ConvertPacket<PacketSignIn_Req>(_p);
                            var ans = new PacketSignIn_Ans(1);
                            ans.isSuccess = await User.SignIn(p.nickName, p.pw);
                            ans.SerialWirte();
                            await SendPacketToSession(_s, ans);
                            logger.WriteDebug($"[Sign in] nickname : {p.nickName} / pw : {p.pw}");
                        }
                        break;
                    case Packet.CONTENT_TYPE.SIGN_OUT:
                        {
                            var p = PacketFactory.Inst.ConvertPacket<PacketSignOut_Req>(_p);
                            var ans = new PacketSignOut_Ans(1);
                            ans.isSuccess = await User.SignOut(p.nickName, p.pw);
                            ans.SerialWirte();
                            await SendPacketToSession(_s, ans);
                            logger.WriteDebug($"[Sign out] nickname : {p.nickName} / pw : {p.pw}");
                        }
                        break;
                    case Packet.CONTENT_TYPE.LOG_IN:
                        {
                            var p = PacketFactory.Inst.ConvertPacket<PacketLogIn_Req>(_p);
                            var ans = new PacketLogIn_Ans();
                            ans.isSuccess = await User.LogIn(p.nickName, p.pw);

                            ans.SerialWirte();
                            await SendPacketToSession(_s, ans);
                            if (ans.isSuccess)
                            {
                                var decDhKey = CryptHelper.RsaDecryptWithBase64(p.dhKey, ConfMgr.mServerConf.privateParam);
                                byte[] dhKeyBytes = Convert.FromBase64String(decDhKey);
                                byte[] dhIvBytes = Convert.FromBase64String(ConfMgr.mServerConf.dh_iv);
                                _s.SetDhInfo(dhKeyBytes, dhIvBytes);
                                logger.WriteDebug($"[Log in {p.nickName}] this user applied aes, key:{decDhKey} iv:{ConfMgr.mServerConf.dh_iv}");
                            }
                        }
                        break;
                    case Packet.CONTENT_TYPE.LOG_OUT:
                        using (var context = ConfMgr.GetDbContext())
                        {
                            var p = PacketFactory.Inst.ConvertPacket<PacketLogOut_Req>(_p);
                            var ans = new PacketLogOut_Ans();
                            ans.isSuccess = await User.LogOut(p.nickName, p.pw);
                            ans.SerialWirte();
                            await SendPacketToSession(_s, ans);
                        }
                        break;

                }
            }
            catch (Exception e)
            {
                logger.Error(e.ToString());
            }
        }
        protected async override Task AnalizerAsync_Ans(CoreSession _s, Packet _p)
        {
            //아직까진 server가 client한테 ans 받을건 없는듯?
            //아마도 server to server인 packet의 처리담당.
            switch (_p.cType)
            {
                default:
                    break;
            }
            return;
        }
        protected async override Task AnalizerAsync_Noti(CoreSession _s, Packet _p)
        {
            switch (_p.cType)
            {
                case Packet.CONTENT_TYPE.HB_CHECK:
                    _s.UpdateHeartBeat();
                    break;
            }
            return;
        }

        protected async override Task AnalizerAsync_Test(CoreSession _s, Packet _p)
        {
            switch (_p.cType)
            {
                case Packet.CONTENT_TYPE.TEST:
                    {
                        var testPacket = PacketFactory.Inst.ConvertPacket<PacketTester>(_p);
                        testPacket.RenderProperties();
                    }
                    break;
                default:
                    break;
            }
        }

    }
}
