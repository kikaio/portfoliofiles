﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CoreNet.Crypt
{
    internal class HashSha256
    {
        public static string PlainStrToBase64WithSha256(string _plainStr, string _saltKey = "")
        {
            //salt 키 추가.
            StringBuilder sb = new StringBuilder(_plainStr);
            sb.Append(_saltKey);
            SHA256Managed shaMgr = new SHA256Managed();
            byte[] encryptedByte = shaMgr.ComputeHash(Encoding.UTF8.GetBytes(sb.ToString()));
            return Convert.ToBase64String(encryptedByte);
        }
    }
}
