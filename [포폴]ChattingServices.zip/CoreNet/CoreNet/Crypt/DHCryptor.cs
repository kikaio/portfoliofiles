﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CoreNet.Crypt
{
    internal class DHCryptor
    {
        public static byte[] DhEncrypt(string _msgBase64, byte[] _key, byte[] _iv)
        {
            var ret = default(byte[]);
            using (var aes = Aes.Create())
            {
                aes.Key = _key;
                aes.IV = _iv;
                ICryptoTransform encryptoy = aes.CreateEncryptor(aes.Key, aes.IV);
                using (var st = new MemoryStream())
                {
                    using (var cs = new CryptoStream(st, encryptoy, CryptoStreamMode.Write))
                    {
                        using (var sr = new StreamWriter(cs))
                        {
                            sr.Write(_msgBase64);
                        }
                    }
                    ret = st.ToArray();
                }
            }
            return ret;
        }

        public static string DhDecrypt(byte[] _bytes, byte[] _key, byte[] _iv)
        {
            var ret = default(string);
            using (var aes = Aes.Create())
            {
                aes.Key = _key;
                aes.IV = _iv;
                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
                using (var st = new MemoryStream(_bytes))
                {
                    using (var cs = new CryptoStream(st, decryptor, CryptoStreamMode.Read))
                    {
                        using (var sr = new StreamReader(cs))
                        {
                            ret = sr.ReadToEnd();
                        }
                    }
                }
            }
            return ret;
        }
    }
}
