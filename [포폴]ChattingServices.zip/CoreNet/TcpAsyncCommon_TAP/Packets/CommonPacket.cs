﻿using CoreNet;
using CoreNet.Networking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TcpAsyncCommon_TAP.Packets
{
    /*
     꼬임, 추후에 packet header를 한번에 쓰고 읽게 하던가 아님 다 수동으로 하던가.
     */
    public interface ICoreSerial
    {
        void SerialRead();
        void SerialWirte();
    }

    //public class Packet_ : Packet, ICoreSerial
    //{
    //    public Packet_(int _capacity = 512)
    //        : base(_capacity)
    //    {
    //    }


    //    internal Packet_(Packet _p)
    //        : base(_p)
    //    {
    //    }
    //    public void SerialRead()
    //    {
    //    }

    //    public void SerialWirte()
    //    {
    //        ClearData();
    //        Translate.Write(data, pType);
    //        Translate.Write(data, cType);
    //        UpdateHeader();
    //    }
    //}

    public class PacketTester : Packet, ICoreSerial
    {
        public long sId { get; set; }
        //public long ticks { get; set; }

        public PacketTester(int _capacity = 64)
        : base(_capacity)
        {
            pType = PACKET_TYPE.TEST;
            cType = CONTENT_TYPE.TEST;
        }

        internal PacketTester(Packet _p)
            : base(_p)
        {

        }

        //public DateTime dt {
        //    get {
        //        return new DateTime(ticks);
        //    }
        //}

        public void DoSetting()
        {
            sId = 15000000;
            //ticks = 3000;
            SerialWirte();
        }
        public void SerialRead()
        {
            sId = Translate.Read<long>(data);
            //ticks = Translate.Read<long>(data);
        }

        public void SerialWirte()
        {
            ClearData();
            Translate.Write(data, pType);
            Translate.Write(data, cType);
            Translate.Write(data, sId);
            //Translate.Write(data, ticks);
            UpdateHeader();
        }

    }

    public class PacketHbCheck_Noti : Packet, ICoreSerial
    {
        public PacketHbCheck_Noti(int _capacity = 0)
            : base(_capacity)
        {
            pType = PACKET_TYPE.NOTI;
            cType = CONTENT_TYPE.HB_CHECK;
        }

        internal PacketHbCheck_Noti(Packet _p)
            :base(_p)
        {

        }

        public void SerialRead()
        {
            ClearData();
        }

        public void SerialWirte()
        {
            //해당 패킷은 data가 없는 패킷.
        }
    }

    public class PacketSignOut_Ans : Packet, ICoreSerial
    {
        public bool isSuccess { get; set; }

        public PacketSignOut_Ans(int _capacity = 512)
            : base(_capacity)
        {
            pType = PACKET_TYPE.ANS;
            cType = CONTENT_TYPE.SIGN_OUT;
        }


        internal PacketSignOut_Ans(Packet _p)
            : base(_p)
        {
        }
        public void SerialRead()
        {
            isSuccess = Translate.Read<bool>(data);
        }

        public void SerialWirte()
        {
            ClearData();
            Translate.Write(data, pType);
            Translate.Write(data, cType);
            Translate.Write(data, isSuccess);
            UpdateHeader();
        }
    }
    public class PacketSignOut_Req : Packet, ICoreSerial
    {
        public string nickName { get; set; }
        public string pw { get; set; }

        public PacketSignOut_Req(int _capacity = 512)
            : base(_capacity)
        {
            pType = PACKET_TYPE.REQ;
            cType = CONTENT_TYPE.SIGN_OUT;
        }


        internal PacketSignOut_Req(Packet _p)
            : base(_p)
        {
        }
        public void SerialRead()
        {
            nickName = Translate.Read<string>(data);
            pw = Translate.Read<string>(data);
        }

        public void SerialWirte()
        {
            ClearData();
            Translate.Write(data, pType);
            Translate.Write(data, cType);
            Translate.Write(data, nickName);
            Translate.Write(data, pw);
            UpdateHeader();
        }
    }
    public class PacketLogOut_Ans : Packet, ICoreSerial
    {
        public bool isSuccess { get; set; }

        public PacketLogOut_Ans(int _capacity = 512)
            : base(_capacity)
        {
            pType = PACKET_TYPE.ANS;
            cType = CONTENT_TYPE.LOG_OUT;
        }

        internal PacketLogOut_Ans(Packet _p)
            : base(_p)
        {
        }

        public void SerialRead()
        {
            isSuccess = Translate.Read<bool>(data);
        }

        public void SerialWirte()
        {
            ClearData();
            Translate.Write(data, pType);
            Translate.Write(data, cType);
            Translate.Write(data, isSuccess);
            UpdateHeader();
        }
    }
    public class PacketLogOut_Req : Packet, ICoreSerial
    {
        public long sId { get; set; }
        public string nickName { get; set; }
        public string pw { get; set; }

        public PacketLogOut_Req(int _capacity = 512)
            : base(_capacity)
        {
            pType = PACKET_TYPE.REQ;
            cType = CONTENT_TYPE.LOG_OUT;
        }


        internal PacketLogOut_Req(Packet _p)
            : base(_p)
        {
        }
        public void SerialRead()
        {
            sId = Translate.Read<long>(data);
            nickName= Translate.Read<string>(data);
            pw= Translate.Read<string>(data);
        }

        public void SerialWirte()
        {
            ClearData();
            Translate.Write(data, pType);
            Translate.Write(data, cType);
            Translate.Write(data, sId);
            Translate.Write(data, nickName);
            Translate.Write(data, pw);
            UpdateHeader();
        }
    }



    //아 그냥 Tool도 만들걸 그랬나....
    public class PacketLogIn_Ans : Packet, ICoreSerial
    {
        public bool isSuccess { get; set; }

        public PacketLogIn_Ans(int _capacity = 512)
            : base(_capacity)
        {
            pType = PACKET_TYPE.ANS;
            cType = CONTENT_TYPE.LOG_IN;
        }

        internal PacketLogIn_Ans(Packet _p)
            : base(_p)
        {
        }
        public void SerialRead()
        {
            isSuccess = Translate.Read<bool>(data);
        }

        public void SerialWirte()
        {
            ClearData();
            Translate.Write(data, pType);
            Translate.Write(data, cType);
            Translate.Write(data, isSuccess);
            UpdateHeader();
        }
    }

    public class PacketLogIn_Req : Packet, ICoreSerial
    {
        public string nickName { get; set; }
        public string pw { get; set; }
        public string dhKey { get; set; }
        public PacketLogIn_Req(int _capacity = 512)
            : base(_capacity)
        {
            pType = PACKET_TYPE.REQ;
            cType = CONTENT_TYPE.LOG_IN;
        }

        internal PacketLogIn_Req(Packet _p)
            : base(_p)
        {
        }
        public void SerialRead()
        {
            nickName = Translate.Read<string>(data);
            pw = Translate.Read<string>(data);
            dhKey = Translate.Read<string>(data);
        }

        public void SerialWirte()
        {
            ClearData();
            Translate.Write(data, pType);
            Translate.Write(data, cType);
            Translate.Write(data, nickName);
            Translate.Write(data, pw);
            Translate.Write(data, dhKey);
            UpdateHeader();
        }
    }
    public class PacketSignIn_Ans : Packet, ICoreSerial
    {
        //회원가입 성공 여부.
        public bool isSuccess { get; set; }
        public PacketSignIn_Ans(int _capacity = 512)
            : base(_capacity)
        {
            pType = PACKET_TYPE.ANS;
            cType = CONTENT_TYPE.SIGN_IN;
        }

        internal PacketSignIn_Ans(Packet _p)
            : base(_p)
        {
        }
        public void SerialRead()
        {
            isSuccess = Translate.Read<bool>(data);
        }

        public void SerialWirte()
        {
            //퉁치기 가능할듯? => property order 확인할 것.
            ClearData();
            Translate.Write(data, pType);
            Translate.Write(data, cType);
            Translate.Write(data, isSuccess);
            UpdateHeader();
        }
    }

    public class PacketSignIn_Req : Packet, ICoreSerial
    {
        public long sId { get; set; }
        public string pw { get; set; }
        public string nickName { get; set; }

        public PacketSignIn_Req(int _capacity = 512)
            : base(_capacity)
        {
            pType = PACKET_TYPE.REQ;
            cType = CONTENT_TYPE.SIGN_IN;
        }

        internal PacketSignIn_Req(Packet _p)
            : base(_p)
        {
        }

        public void SerialRead()
        {
            sId = Translate.Read<long>(data);
            pw = Translate.Read<string>(data);
            nickName = Translate.Read<string>(data);
        }

        public void SerialWirte()
        {
            ClearData();
            Translate.Write(data, pType);
            Translate.Write(data, cType);
            Translate.Write(data, sId);
            Translate.Write(data, pw);
            Translate.Write(data, nickName);
            UpdateHeader();
        }
    }


    public class PacketWelcome : Packet, ICoreSerial
    {
        public long sId { get; set; }
        public PacketWelcome(int _capacity = 512) : base(_capacity)
        {
            pType = PACKET_TYPE.ANS;
            cType = CONTENT_TYPE.WELCOME;
        }

        //해당 생성자는 반드시 Factory에서만 호출할 것.
        internal PacketWelcome(Packet _p)
            : base(_p)
        {
        }

        public void SerialRead()
        {
            sId = Translate.Read<long>(data);
        }

        public void SerialWirte()
        {
            ClearData();
            Translate.Write(data, pType);
            Translate.Write(data, cType);
            Translate.Write(data, sId);
            UpdateHeader();
        }
    }

    public class PacketChat_Req : Packet, ICoreSerial
    {
        public long sId { get; set; }
        public long ticks { get; set; }
        public string chat { get; set; } = "";
        public PacketChat_Req(int _capacity = 512)
            : base(_capacity)
        {
            pType = PACKET_TYPE.REQ;
            cType = CONTENT_TYPE.CHATTING;
        }
        internal PacketChat_Req(Packet _p)
            : base(_p)
        {
        }

        public void SerialRead()
        {
            sId = Translate.Read<long>(data);
            ticks = Translate.Read<long>(data);
            chat = Translate.Read<string>(data);
        }

        public void SerialWirte()
        {
            ClearData();
            Translate.Write(data, pType);
            Translate.Write(data, cType);
            Translate.Write(data, sId);
            Translate.Write(data, ticks);
            Translate.Write(data, chat);
            UpdateHeader();
        }
    }
    public class PacketChat_Ans : Packet, ICoreSerial
    {
        public long sId { get; set; }
        public long ticks { get; set; }
        public string chat { get; set; }

        public PacketChat_Ans(int _capacity = 512)
            : base(_capacity)
        {
            pType = PACKET_TYPE.ANS;
            cType = CONTENT_TYPE.CHATTING;
        }

        internal PacketChat_Ans(Packet _p)
            : base(_p)
        {
        }

        public void SerialRead()
        {
            sId = Translate.Read<long>(data);
            ticks = Translate.Read<long>(data);
            chat = Translate.Read<string>(data);
        }

        public void SerialWirte()
        {
            ClearData();
            //to do : 나중에 퉁칠수 있게 하자.
            //foreach (var prop in this.GetType().GetProperties())
            //{
            //    if (prop.Name == "header" || prop.Name == "data")
            //        continue;
            //    Type pType = prop.PropertyType;
            //    Translate.Write(data, );
            //}
            Translate.Write(data, pType);
            Translate.Write(data, cType);
            Translate.Write(data, sId);
            Translate.Write(data, ticks);
            Translate.Write(data, chat);
            UpdateHeader();
        }
    }
}
