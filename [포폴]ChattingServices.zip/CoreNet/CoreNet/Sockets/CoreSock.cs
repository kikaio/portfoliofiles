﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net.Sockets;
using System.Net;
using CoreNet.Networking;

namespace CoreNet.Sockets
{

    public abstract class CoreSock
    {
        public Socket Sock;
        public int Port;
        public IPAddress Addr;

        //public abstract void send(Packet _p);
        //public abstract Packet recv();
    }

    public class CoreTCP : CoreSock
    {
        public CoreTCP(Socket _sock)
        {
            Sock = _sock;
        }

        public CoreTCP(AddressFamily _af = AddressFamily.InterNetwork)
        {
            Sock = new Socket(_af, SocketType.Stream, ProtocolType.Tcp);
        }

        //public override Packet recv()
        //{
        //    Packet p = new Packet();
        //    int remainCnt = p.GetHeaderSize();
        //    while (remainCnt > 0)
        //    {
        //        remainCnt -= Sock.Receive(p.header.bytes, p.GetHeaderSize() - remainCnt, SocketFlags.None);
        //    }
        //    remainCnt = p.GetHeader();
        //    while (remainCnt > 0)
        //    {
        //        remainCnt -= Sock.Receive(p.data.bytes, p.GetHeader() - remainCnt, SocketFlags.None);
        //    }

        //    return p;
        //}

        //public override void send(Packet _p)
        //{
        //    int remainCnt = _p.GetHeaderSize();
        //    while (remainCnt > 0)
        //    {
        //        remainCnt -= Sock.Send(_p.header.bytes, _p.GetHeaderSize() - remainCnt, SocketFlags.None);
        //    }
        //    remainCnt = _p.GetHeader();
        //    while (remainCnt > 0)
        //    {
        //        remainCnt -= Sock.Send(_p.data.bytes, _p.GetHeaderSize() - remainCnt, SocketFlags.None);
        //    }

        //}
    }
    public class CoreUDP : CoreSock
    {
        public CoreUDP(AddressFamily _af = AddressFamily.InterNetwork)
        {
            Sock = new Socket(_af, SocketType.Dgram, ProtocolType.IP);
        }

        //        public override Packet recv()
        //        {
        //            Packet p = new Packet();
        //            throw new NotImplementedException();
        ////            return p;
        //        }

        //        public override void send(Packet _p)
        //        {
        //            throw new NotImplementedException();
        //        }
    }
}
