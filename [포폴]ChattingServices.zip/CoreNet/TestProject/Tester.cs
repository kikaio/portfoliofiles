﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject
{
    public abstract class Tester
    {
        public abstract void DoTest();

        public void RenderBytes(byte[] _bytes, string _tag = "")
        {
            StringBuilder sb = new StringBuilder(_tag);
            for (int i = 0; i < _bytes.Length; i++)
            {
                sb.Append($"[{_bytes[i]}]");
            }
            Console.WriteLine(sb.ToString());
        }
    }
}
