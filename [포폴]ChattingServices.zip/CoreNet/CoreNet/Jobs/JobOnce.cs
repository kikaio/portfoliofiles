﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreNet.Jobs
{
    public class JobOnce : Job
    {
        //단 한번만 실행하는 job
        //해당 job에서 무한반복 쓰는 경우는 주의 할 것.
        public JobOnce(Action _jobAct = null, DateTime _sDate = new DateTime())
        {
            JobAct = _jobAct;
            StartDate = _sDate;
        }
        //false 반환 시 job 삭제됨.
        public override bool Tick()
        {
            if (StartDate < DateTime.UtcNow)
                return true;
            JobAct?.Invoke();
            return false;
        }
    }
}
