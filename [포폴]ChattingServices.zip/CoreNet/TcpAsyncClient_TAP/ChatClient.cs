﻿using CoreNet;
using CoreNet.Clients;
using CoreNet.Crypt;
using CoreNet.Jobs;
using CoreNet.Networking;
using CoreNet.Sockets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TcpAsyncCommon_TAP.Packets;

namespace CoreChatClient
{
    public class ChatClient : CoreClient
    {
        class UserData
        {
            public string public_RsaKey;
            public long sessionId;
            public string nickName;
            public string password;
            public byte[] dh_key;       //이게 맞나..?
            public byte[] dh_iv;       //이게 맞나..?
        }


        Worker cmdWorker = new Worker("cmdWorker", true);
        Worker pkgWorker = new Worker("pkgWorker", true);
        Worker recvWorker = new Worker("recvWorker", true);
        Worker hbSender = new Worker("hbSender", true);

        CancellationTokenSource clientDownTS = new CancellationTokenSource();

        ClientConf mConf = ClientConf.Create();

        public ChatClient()
            : base("ChatClient")
        {
            shutdownAct = clientShutdown;
            port = 30000;
            ipAddrStr = "127.0.0.1";

            mUser.dh_key = mConf.mDhSecret.Key;
            mUser.dh_iv = mConf.mDhSecret.IV;
            mUser.public_RsaKey = mConf.public_key;


            mTestUser.nickName = "testUser";
            mTestUser.password = "test1234";
            mTestUser.dh_key = mConf.mDhSecret.Key;
            mTestUser.dh_iv = mConf.mDhSecret.IV;
            mTestUser.public_RsaKey = mConf.public_key;


            heartBeatPacket = new PacketHbCheck_Noti();
        }

        UserData mUser = new UserData();
        UserData mTestUser = new UserData();

        protected override bool Connect()
        {
            try
            {
                ep = new IPEndPoint(IPAddress.Parse(ipAddrStr), port);
                CoreTCP tcp = new CoreTCP();
                tcp.Sock.NoDelay = true;
                tcp.Sock.Connect(ep);
                mSession = new CoreSession(-1, tcp);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        private async Task SendPacket(Packet _p)
        {
            if (await mSession.OnSendTAP(_p))
                logger.WriteDebug("packet send success");
            else
            {
                logger.WriteDebugWarn("Graceful shutdown start, and shutdown client");
                GracefulSessionClose();
                shutdownAct();
            }
        }

        private async Task<bool> RecvPacket()
        {
            var packet = await mSession.OnRecvTAP();
            if (packet != null)
                packageQ.Push(new Package(mSession, packet));
            else
            {
                logger.WriteDebugWarn("Graceful shutdown start, and shutdown client");
                GracefulSessionClose();
                shutdownAct();
                return false;
            }
            return true;
        }
        
        //send to Sign in REQ packet
        private async Task DoSignIn_Req(List<string> _params = null)
        {
            var p = new PacketSignIn_Req();
            mUser.sessionId = mSession.SessionId;
            if (_params != null)
            {
                mUser.nickName = _params[0];
                mUser.password = _params[1];
            }
            else
            {
                logger.WriteDebug("input data가 적어 test data로 대체합니다.");
                mTestUser.nickName = $"{mTestUser.nickName}_{mSession.SessionId}";
                mUser.nickName = mTestUser.nickName;
                mUser.password = mTestUser.password;
            }

            p.sId = mUser.sessionId;
            p.nickName = mUser.nickName;
            p.pw = mUser.password;
            //RSA 암호화
            byte[] utfBytes = Encoding.UTF8.GetBytes(p.pw);
            string pwWithBase = Convert.ToBase64String(utfBytes);
            p.pw = CryptHelper.RsaEncryptWithBase64(pwWithBase, mConf.publicParam);

            p.SerialWirte();
            await SendPacket(p);
        }

        private async Task DoSignOut_Req(List<string> _params = null)
        {
            var p = new PacketSignOut_Req();
            if (_params == null)
            {
                logger.WriteDebug("input data가 적어 test data로 대체합니다.");
                mUser.nickName = mTestUser.nickName;
                mUser.password = mTestUser.password;
                
            }
            else
            {
                mUser.nickName = _params[0];
                mUser.password = _params[1];
            }
            p.nickName = mUser.nickName;
            p.pw = mUser.password;
            logger.WriteDebug($"[try sign out]{p.nickName} / {p.pw}");

            byte[] utfBytes = Encoding.UTF8.GetBytes(p.pw);
            string pwWithBase = Convert.ToBase64String(utfBytes);
            p.pw = CryptHelper.RsaEncryptWithBase64(pwWithBase, mConf.publicParam);

            p.SerialWirte();
            await SendPacket(p);
        }
        private async Task DoLogIn_Req(List<string> _params = null)
        {
            var p = new PacketLogIn_Req();
            if (_params == null)
            {
                logger.WriteDebug("input data가 적어 test data로 대체합니다.");
                mUser.nickName = mTestUser.nickName;
                mUser.password = mTestUser.password;
            }
            else
            {
                logger.WriteDebug($"[try log in]{_params[0]}/{_params[1]}");
                mUser.nickName = _params[0];
                mUser.password = _params[1];
            }

            p.nickName = mUser.nickName;
            p.pw = mUser.password;
            byte[] utfBytes = Encoding.UTF8.GetBytes(p.pw);
            string pwWithBase = Convert.ToBase64String(utfBytes);
            p.pw = CryptHelper.RsaEncryptWithBase64(pwWithBase, mConf.publicParam);
            p.dhKey = CryptHelper.RsaEncryptWithBase64(mConf.dh_key, mConf.publicParam);
            p.SerialWirte();
            await SendPacket(p);
        }

        private async Task DoLogOut_Req(List<string> _params = null)
        {
            var p = new PacketLogOut_Req();
            if (_params == null)
            {
                logger.WriteDebug("input data가 적어 test data로 대체합니다.");
                mUser.nickName = mTestUser.nickName;
                mUser.password = mTestUser.password;
            }
            else
            {
                mUser.nickName = _params[0];
                mUser.password = _params[1];
            }
            logger.WriteDebug($"[try logout]{mUser.nickName}/{mUser.password}");

            p.nickName = _params[0];
            p.pw = _params[1];

            byte[] utfBytes = Encoding.UTF8.GetBytes(p.pw);
            string pwWithBase = Convert.ToBase64String(utfBytes);
            p.pw = CryptHelper.RsaEncryptWithBase64(pwWithBase, mConf.publicParam);
            p.SerialWirte();
            await SendPacket(p);
        }

        private async Task DoChat_Req(string _msg = null)
        {
            var p = new PacketChat_Req();
            p.sId = mSession.SessionId;
            p.ticks = DateTime.UtcNow.Ticks;
            p.chat = _msg;
            p.SerialWirte();

            await SendPacket(p);
        }

        private async Task DoTest_Test(List<string> _params = null)
        {
            var p = new PacketTester();
            p.DoSetting();
            await SendPacket(p);
        }

        private void ReadyWorkers()
        {
            Job cmdJob = new JobInfinity(async () => {
                string cmd = Console.ReadLine();
                var cmds = cmd.Split(' ').ToList();
                if (clientDownTS.IsCancellationRequested)
                    return;
                var head = cmds[0].ToUpper();
                cmds.RemoveAt(0);
                
                switch (head)
                {
                    case "EXIT":
                        shutdownAct();
                        break;
                    case "SIGN":
                        {
                            if (cmds.Count == 0)
                            {
                                logger.Error("cmd가 정확히 입력되지 않았습니다.");
                                return;
                            }
                            var s = cmds[0].ToUpper();
                            cmds.RemoveAt(0);
                            if (s == "IN")
                                await DoSignIn_Req(cmds);
                            else if (s == "OUT")
                                await DoSignOut_Req(cmds);
                        }
                        break;
                    case "LOG":
                        {
                            if (cmds.Count == 0)
                            {
                                logger.Error("cmd가 정확히 입력되지 않았습니다.");
                                return;
                            }
                            var s = cmds[0].ToUpper();
                            cmds.RemoveAt(0);
                            if (s == "IN")
                                await DoLogIn_Req(cmds);
                            else if (s == "OUT")
                                await DoLogOut_Req(cmds);
                        }
                        break;
                    case "TEST":
                        await DoTest_Test();
                        break;
                    default://채팅말고 할게 있나?
                        await DoChat_Req(cmd);
                        break;
                }
            });
            Job pkgJob = new JobInfinity(async () => {
                if (clientDownTS.IsCancellationRequested)
                    return;
                packageQ.Swap();
                while (clientDownTS.IsCancellationRequested == false)
                {
                    var pkg = packageQ.pop();
                    if (pkg == null)
                        break;
                    await PackageDispatcherAsync(pkg);
                }
            });
           
            long delta = TimeSpan.FromMilliseconds(CoreSession.hbDelayMilliSec).Ticks;
            Job hbJob = new JobInfinity(async () => {
                //welcome packet 수령전에는 hb 안보낸다.
                if (clientDownTS.IsCancellationRequested && mUser.sessionId == 0)
                    return;
                //hb check시간보다는 짧은 간격으로 hb packet을 보낸다.
                await SendPacket(new PacketHbCheck_Noti());
            }, default(DateTime), (long)(delta * 0.75));

            cmdWorker.PushJob(cmdJob);
            pkgWorker.PushJob(pkgJob);
            hbSender.PushJob(hbJob);
        }

        public override void ReadyToStart()
        {
            ReadyWorkers();
        }

        public override void Start()
        {
            if (Connect() == false)
            {
                logger.Error("client connect was failed");
                Console.ReadKey();
                return;
            }

            cmdWorker.WorkStart();
            pkgWorker.WorkStart();
            //recvWorker.WorkStart();
            hbSender.WorkStart();
            Task.Factory.StartNew(async () =>
            {
                while (clientDownTS.IsCancellationRequested == false)
                {
                    await RecvPacket();
                }
            });
            while (isDown == false)
            {
                Thread.Sleep(100);
            }
        }

        private void clientShutdown()
        {

            logger.WriteDebugWarn("client is down after 3 minuite");
            clientDownTS.Cancel();
            cmdWorker.WorkFinish();
            pkgWorker.WorkFinish();
            recvWorker.WorkFinish();
            hbSender.WorkFinish();

            Thread.Sleep(1000 * 3 * 60);
            //process 종료. => 추가할 것.
        }

        protected override void Analizer_Ans(CoreSession _s, Packet _p)
        {
            throw new NotImplementedException("don't use this method in client");
        }

        protected override void Analizer_Noti(CoreSession _s, Packet _p)
        {
            throw new NotImplementedException("don't use this method in client");
        }

        protected override void Analizer_Req(CoreSession _s, Packet _p)
        {
            throw new NotImplementedException("don't use this method in client");
        }
        protected override void Analizer_Test(CoreSession _s, Packet _p)
        {
            throw new NotImplementedException("don't use this method in client");
        }

        protected override async Task AnalizerAsync_Req(CoreSession _s, Packet _p)
        {
            switch (_p.cType)
            {
                default:
                    break;
            }
            return;
        }

        protected override async Task AnalizerAsync_Ans(CoreSession _s, Packet _p)
        {

            switch (_p.cType)
            {
                case Packet.CONTENT_TYPE.WELCOME:
                    {
                        var p = PacketFactory.Inst.ConvertPacket<PacketWelcome>(_p);
                        if (p == null)
                            break;
                        mSession.SetSessionId(p.sId);
                        mUser.sessionId = p.sId;
                        mTestUser.sessionId = p.sId;
                        logger.WriteDebug("recved Welcome ans");
                    }
                    break;
                case Packet.CONTENT_TYPE.CHATTING:
                    {
                        var p = PacketFactory.Inst.ConvertPacket<PacketChat_Ans>(_p);
                        DateTime sendDt = new DateTime(p.ticks).AddHours(+9);   //한국 로컬 시간으로 표시.
                        logger.Write($"msg from [{p.sId}]: {p.chat} at {sendDt.ToString("yy-MM-dd HH:mm:ss")}");
                    }
                    break;
                case Packet.CONTENT_TYPE.SIGN_IN:
                    {
                        var p = PacketFactory.Inst.ConvertPacket<PacketSignIn_Ans>(_p);
                        if (p.isSuccess)
                            logger.WriteDebug("Success sign in");
                        else
                            logger.WriteDebug("Failed sign in");
                    }
                    break;
                case Packet.CONTENT_TYPE.SIGN_OUT:
                    {
                        var p = PacketFactory.Inst.ConvertPacket<PacketSignOut_Ans>(_p);
                        if (p.isSuccess)
                            logger.WriteDebug("Success sign out");
                        else
                            logger.WriteDebug("Failed sign out");
                    }
                    break;
                case Packet.CONTENT_TYPE.LOG_IN:
                    {
                        var p = PacketFactory.Inst.ConvertPacket<PacketLogIn_Ans>(_p);
                        if (p.isSuccess)
                        {
                            logger.WriteDebug("Success log in to chat server");
                            mSession.SetDhInfo(mConf.mDhSecret.Key, mConf.mDhSecret.IV);
                            logger.WriteDebug($"session Aes Applied, key:{Convert.ToBase64String(mConf.mDhSecret.Key)} iv:{Convert.ToBase64String(mConf.mDhSecret.IV)}");
                        }
                        else
                            logger.WriteDebug("Failed log in to chat server");
                    }
                    break;
                case Packet.CONTENT_TYPE.LOG_OUT:
                    {
                        var p = PacketFactory.Inst.ConvertPacket<PacketLogOut_Ans>(_p);
                        if (p.isSuccess)
                            logger.WriteDebug("Success log out to chat server");
                        else
                            logger.WriteDebug("Failed log out to chat server");
                    }
                    break;
                default:
                    break;
            }
            return;
        }

        protected override async Task AnalizerAsync_Noti(CoreSession _s, Packet _p)
        {
            switch (_p.cType)
            {
                default:
                    break;
            }
            return;
        }

        protected override async Task AnalizerAsync_Test(CoreSession _s, Packet _p)
        {
            return;
        }

    }
}

