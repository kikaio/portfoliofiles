﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using CoreNet.Jobs;
using CoreNet.Networking;
using CoreNet.Sockets;

namespace CoreNet.Servers
{
    public abstract class CoreServer : CoreNetwork
    {
        protected CoreSock listenSock;

        public List<CoreSession> expiredSessionList = new List<CoreSession>();

        public CoreServer(string _name, int _port, Action _shutdown = null)
            : base(_name)
        {
            name = _name;
            shutdownAct = _shutdown;
        }

        protected abstract void BindAndListen();

        protected void CheckHeartBeats()
        {
            if (isDown)
                return;
            foreach (var s in SessionMgr.Inst.ToSessonList())
            {
                if (s.HeartBeat < DateTime.UtcNow)
                    expiredSessionList.Add(s);
            }

            foreach (var s in expiredSessionList)
            {
                var removed = default(CoreSession);
                if (SessionMgr.Inst.CloseSession(s.SessionId, out removed))
                    logger.WriteDebug($"session[{removed.SessionId}]'s heartbeat is expired and removed");
            }
        }
    }
}
