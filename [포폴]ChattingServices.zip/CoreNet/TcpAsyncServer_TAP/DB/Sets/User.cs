﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Cryptography;
using System.Data.Entity;
using TcpAsyncServer_TAP.Configs;
using CoreNet.Crypt;

namespace CoreChatServer.DB.Sets
{
    [Serializable]
    [Table("Users")]
    public class User
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }
        [Required, Index(IsUnique = true)]
        public string NickName { get; set; }
        [Required]
        public string pw { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public DateTime RegistedDate { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public DateTime UpdatedDate { get; set; }
        public bool IsBlocked { get; set; }


        public static async Task<bool> SignIn(string _nickname, string _rsaEncryptedPw)
        {
            try
            {
                using (var context = ConfMgr.GetDbContext())
                {
                    var user = await context.Users.SingleOrDefaultAsync(x => x.NickName == _nickname);
                    if (user != default(User))
                        return false;

                    var rsaPw = CryptHelper.RsaDecryptWithBase64(_rsaEncryptedPw, ConfMgr.mServerConf.privateParam);
                    var plainPw = Encoding.UTF8.GetString(Convert.FromBase64String(rsaPw));
                    user = new User();
                    user.NickName = _nickname;
                    //key salting 적용
                    var encryptedPw = CryptHelper.PlainStrToBase64WithSha256(plainPw, user.NickName);
                    user.pw = encryptedPw;
                    context.Users.Add(user);
                    Console.WriteLine($"[{_nickname}/{plainPw}] try sign in : {encryptedPw}");
                    await context.SaveChangesAsync();
                }
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                return false;
            }
        }
        public static async Task<bool> SignOut(string _nickName, string _oriPw)
        {
            var decryptBase64 = CryptHelper.RsaDecryptWithBase64(_oriPw, ConfMgr.mServerConf.privateParam);
            var plainPw = Encoding.UTF8.GetString(Convert.FromBase64String(decryptBase64));
            using (var context = ConfMgr.GetDbContext())
            {
                var base64Str = CryptHelper.PlainStrToBase64WithSha256(plainPw, _nickName);
                Console.WriteLine($"[{_nickName}/{plainPw}]try sign out : {base64Str}");
                var user = await context.Users.SingleOrDefaultAsync(x => x.NickName == _nickName && x.pw == base64Str);
                if (user != null)
                {
                    context.Users.Remove(user);
                    await context.SaveChangesAsync();
                    return true;
                }
                else
                    return false;
            }
        }


        public static async Task<bool> LogIn(string _nickName, string _oriPw)
        {
            try
            {
                var decryptBase64 = CryptHelper.RsaDecryptWithBase64(_oriPw, ConfMgr.mServerConf.privateParam);
                var plainPw = Encoding.UTF8.GetString(Convert.FromBase64String(decryptBase64));
                using (var context = ConfMgr.GetDbContext())
                {
                    var base64Str = CryptHelper.PlainStrToBase64WithSha256(plainPw, _nickName);
                    Console.WriteLine($"[{_nickName}/{plainPw}]try login : {base64Str}");
                    var user = await context.Users.AsNoTracking().SingleOrDefaultAsync(x => x.NickName == _nickName && x.pw == base64Str);
                    if (user != null)
                        return true;
                    else 
                        return false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                return false;
            }
        }

        public static async Task<bool> LogOut(string _nickName, string _oriPw)
        {
            //해당 user logout 처리
            try
            {
                var decryptBase64 = CryptHelper.RsaDecryptWithBase64(_oriPw, ConfMgr.mServerConf.privateParam);
                var plainPw = Encoding.UTF8.GetString(Convert.FromBase64String(decryptBase64));
                using (var context = ConfMgr.GetDbContext())
                {
                    var base64Str = CryptHelper.PlainStrToBase64WithSha256(plainPw, _nickName);
                    Console.WriteLine($"[{_nickName}/{plainPw}]try logout : {base64Str}");
                    var user = await context.Users.AsNoTracking().SingleOrDefaultAsync(x => x.NickName == _nickName && x.pw == base64Str);
                    if (user != null)
                    {
                        Console.WriteLine($"[logout {_nickName}/{plainPw}] sha encrypted pw : {base64Str}");
                        return true;
                    }
                    else
                        Console.WriteLine($"[logout {_nickName}/{plainPw}]this data something wrong");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            return false;
        }
    }
}
