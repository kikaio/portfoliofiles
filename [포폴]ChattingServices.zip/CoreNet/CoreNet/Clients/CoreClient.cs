﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using CoreNet.Jobs;
using CoreNet.Networking;
using CoreNet.Sockets;
using CoreNet.Utils.LockHelper;

namespace CoreNet.Clients
{
    using ConnAct = Func<CoreSock, bool>;
    public abstract class CoreClient : CoreNetwork
    {
        protected CoreSession mSession;
        protected Packet heartBeatPacket = new Packet();
        //protected LockedSwapQ<Packet> packetQ = new LockedSwapQ<Packet>();

        public CoreClient(string _name, Action _shutdownAct = null)
            : base("CoreClient")
        {
            shutdownAct = _shutdownAct;
        }

        protected abstract bool Connect();

        protected void GracefulSessionClose()
        {
            mSession.Sock.Sock.Disconnect(true);
            mSession.Sock.Sock.Close();
        }

        protected void ShutdownSessionClose()
        {
            mSession.Sock.Sock.Shutdown(SocketShutdown.Both);
            mSession.Sock.Sock.Close();
        }
    }
}
