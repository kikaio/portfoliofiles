﻿using CoreChatServer.Configs;
using CoreChatServer.DB;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TcpAsyncServer_TAP.Configs
{
    public class ConfMgr
    {
        public static ServerConf mServerConf { get; private set; }
        public static MysqlConf mDbConf { get; private set; }

        public static void Init()
        {
            try
            {
                var settings = ConfigurationManager.AppSettings;
                var dbConfPath = settings.Get("DbConfig");
                var serverConfPath = settings.Get("ServerConfig");
                mServerConf = ServerConf.Create(serverConfPath);
                mDbConf = MysqlConf.Create(dbConfPath);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        public static SimpleContext GetDbContext()
        {
            return new SimpleContext(mDbConf.GetConnStr());
        }
    }
}
