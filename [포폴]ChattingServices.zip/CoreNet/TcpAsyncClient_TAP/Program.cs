﻿using CoreChatClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TcpAsyncClient_TAP
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                ChatClient client = new ChatClient();
                client.ReadyToStart();
                client.Start();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("Chat finishied, press any key");
            Console.ReadKey();
        }
    }
}
