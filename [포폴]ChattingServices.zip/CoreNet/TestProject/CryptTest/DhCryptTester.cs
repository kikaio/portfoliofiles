﻿using CoreNet;
using CoreNet.Networking;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using TcpAsyncCommon_TAP.Packets;

namespace TestProject.CryptTest
{
    public class DhCryptTester : Tester
    {
        public void TestStart()
        {

        }

        public override void DoTest()
        {
            Translate.Init();


            byte[] encKey = Encoding.UTF8.GetBytes("test");
            using (var aes = Aes.Create())
            {

                string keyBase = "A63qL9xZKzDExsJxGMffZCtQV44Lt9+3jsDrkMirbZc=";
                string ivBase = "Cj6mFNB/hde+PaZqM22W3g==";

                aes.Key = Convert.FromBase64String(keyBase);
                aes.IV = Convert.FromBase64String(ivBase);

                var req = new PacketTester();
                req.DoSetting();
                RenderBytes(req.data.bytes, "[before enc]\n");
                //req.data.DoXorCrypt(encKey);
                req.data.DoDhEncrypt(aes.Key, aes.IV);
                req.UpdateHeader();
                RenderBytes(req.data.bytes, "[after dec]");

                var ans = new Packet(req.GetHeader());
                Array.Copy(req.header.bytes, 0, ans.header.bytes, 0, Packet.GetHeaderSize());
                Array.Copy(req.data.bytes, 0, ans.data.bytes, 0, req.GetHeader());
                RenderBytes(ans.data.bytes, "[before dec]");
                //ans.data.DoXorCrypt(encKey);
                ans.data.DoDhDeCrypt(aes.Key, aes.IV);

                RenderBytes(ans.data.bytes, "[after dec]");
                ans.ReadPacketType();
                ans.ReadContent();

                var testP = PacketFactory.Inst.ConvertPacket<PacketTester>(ans);
                testP.RenderProperties();
                return;
            }
        }

        //public byte[] DoEncrypt(string _msgBase64, byte[] _key, byte[] _iv)
        //{
        //    var ret = default(byte[]);
        //    using (var aes = Aes.Create())
        //    {
        //        aes.Key = _key;
        //        aes.IV = _iv;
        //        ICryptoTransform encryptoy = aes.CreateEncryptor(aes.Key, aes.IV);
        //        using (var st = new MemoryStream())
        //        {
        //            using (var cs = new CryptoStream(st, encryptoy, CryptoStreamMode.Write))
        //            {
        //                using (var sr = new StreamWriter(cs))
        //                {
        //                    sr.Write(_msgBase64);
        //                }
        //            }
        //           ret = st.ToArray();
        //        }
        //    }
        //    return ret;
        //}

        //public string DoDecrypt(byte[] _bytes, byte[] _key, byte[] _iv)
        //{
        //    var ret = default(string);
        //    using (var aes = Aes.Create())
        //    {
        //        aes.Key = _key;
        //        aes.IV = _iv;
        //        ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
        //        using (var st = new MemoryStream(_bytes))
        //        {
        //            using (var cs = new CryptoStream(st, decryptor, CryptoStreamMode.Read))
        //            {
        //                using (var sr = new StreamReader(cs))
        //                {
        //                    ret = sr.ReadToEnd();
        //                }
        //            }
        //        }
        //    }
        //    return ret;
        //}
    }
}
