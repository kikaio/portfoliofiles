﻿using CoreChatServer.DB.Sets;
using CoreNet.Database;
using MySql.Data.EntityFramework;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CoreChatServer.DB
{
    [DbConfigurationType(typeof(MySqlEFConfiguration))]
    public class SimpleContext : CoreDBContext
    {
        public SimpleContext(string _conStr)
            : base(_conStr)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<ChatLog> ChatLogs { get; set; }
        public DbSet<ServerData> ChatServerDatas { get; set; }
    }
}
