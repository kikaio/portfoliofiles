﻿using CoreNet.Utils.Loggers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreNet.Tests
{
    public abstract class Tester : IDisposable
    {
        protected bool isFin { get; private set; } = false;
        protected ConsoleLogger logger = new ConsoleLogger();

        private bool isDisposed = false;

        protected Tester(string _tName)
        {
            logger.WriteDebug($"{_tName} is created");
        }
        protected void TestFin()
        {
            isFin = true;
            Console.ReadKey();
        }

        public void DoTestLoop()
        {
            while (isFin == false)
            {
                TestLogic();
            }
            logger.Write("Test is over");
        }

        protected abstract void TestLogic();

        protected virtual void DoDispose(bool _flag)
        {
            if (isDisposed)
                return;
            {
            }
            GC.SuppressFinalize(this);
            isDisposed = true;
        }

        public void Dispose()
        {
            logger.Write("test disposed");
            DoDispose(isDisposed);
        }
    }
}
