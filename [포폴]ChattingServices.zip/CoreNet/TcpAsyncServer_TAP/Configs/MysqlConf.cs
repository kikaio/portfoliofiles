﻿using CoreNet.Utils.Json;
using CoreNet.Utils.Loggers;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreChatServer.Configs
{
    public class MysqlConf : JsonicObj
    {
        
        internal static MysqlConf Create(string _confFilePath)
        {
            //test_db의 context 생성
            try
            {
                using (var sr = new StreamReader(_confFilePath))
                {
                    string jobjStr = sr.ReadToEnd();
                    var ret = new MysqlConf(jobjStr);
                    return ret;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                throw;
            }
        }

        public string server { get; private set; }
        public int port { get; private set; }
        public string database { get; private set; }
        public string uid { get; private set; }
        public string password { get; private set; }
        public int ConnectionTimeout { get; private set; }

        private MysqlConf(string _jsonStr)
            :base(JObject.Parse(_jsonStr))
        {

        }
        private MysqlConf(JObject _jobj)
            : base(_jobj)
        {
        }

        public string GetConnStr()
        {
            StringBuilder sb = new StringBuilder();
            var pList = GetType().GetProperties();
            foreach (var pInfo in pList)
            {
                if (pInfo.Name == "ConnectionTimeout")
                    sb.Append($"Connection Timeout={pInfo.GetValue(this)};");
                else
                   sb.Append($"{pInfo.Name}={pInfo.GetValue(this)};");
            }
            return sb.ToString();
        }

    }
}
