﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CoreNet.Crypt
{
    internal class RsaCryptor
    {
        public static string RsaEncryptWithBase64(string _val, RSAParameters _publicParam)
        {
            using (var rsa = new RSACryptoServiceProvider())
            {
                byte[] _data = Convert.FromBase64String(_val);
                rsa.ImportParameters(_publicParam);
                byte[] encrypted = rsa.Encrypt(_data, false);
                return Convert.ToBase64String(encrypted);
            }
        }

        public static string RsaDecryptWithBase64(string _val, RSAParameters _privateParam)
        {
            using (var rsa = new RSACryptoServiceProvider())
            {
                rsa.ImportParameters(_privateParam);
                byte[] _data = Convert.FromBase64String(_val);
                byte[] decBuf = rsa.Decrypt(_data, false);
                return Convert.ToBase64String(decBuf);
            }
        }

    }
}
