﻿using CoreNet.Utils.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Configuration;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace CoreChatClient
{
    public class ClientConf : JsonicObj
    {
        public string public_key { get; set; }
        public string dh_key;
        public string dh_iv { get; set; }
        public Aes mDhSecret = Aes.Create();
        public RSAParameters publicParam;


        public static ClientConf Create()
        {
            try
            {
                var ret = default(ClientConf);
                var settings = ConfigurationManager.AppSettings;
                var confFilePath = settings.Get("ClientConf");
                using (var rs = new StreamReader(confFilePath))
                {
                    string json = rs.ReadToEnd();
                    ret = new ClientConf(json);
                   
                }
                return ret;
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        private ClientConf(string _json)
            : this(JObject.Parse(_json))
        {
            Init();
        }

        protected ClientConf(JObject _jObj)
            : base(_jObj)
        {
        }

        private void Init()
        {
            var xmlSer = new XmlSerializer(typeof(RSAParameters));
            var sr = new StringReader(public_key);
            publicParam = (RSAParameters)xmlSer.Deserialize(sr);
            //IV의 경우 읽어오는것 말고 gen하는것도 가능할듯.
            mDhSecret.IV = Convert.FromBase64String(dh_iv);
            mDhSecret.GenerateKey();
            dh_key = Convert.ToBase64String(mDhSecret.Key);
        }
    }
}
