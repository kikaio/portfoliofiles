﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoreChatServer.DB.Sets
{
    [Serializable]
    [Table("ServerDatas")]
    public class ServerData
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        public int Category { get; set; }

        public string HostName { get; set; }

        public string PublicIp { get; set; }

        public int PublicPort { get; set; }

        public string PrivateIp { get; set; }

        public int PrivatePort { get; set; }
        //설명.
        public string About { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public DateTime UpdatedDate { get; set; }
    }
}
