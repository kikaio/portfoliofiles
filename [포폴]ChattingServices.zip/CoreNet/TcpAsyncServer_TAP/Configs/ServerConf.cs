﻿using CoreNet.Utils.Json;
using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Xml.Serialization;

namespace CoreChatServer.Configs
{
    public class ServerConf : JsonicObj
    {
        internal static ServerConf Create(string _confPath)
        {
            var ret = default(ServerConf);
            string str = string.Empty;
            using (var fs = new StreamReader(_confPath, Encoding.UTF8))
            {
                str = fs.ReadToEnd();
            }
            JObject json = JObject.Parse(str);
            ret = new ServerConf(json, _confPath);
            return ret;
        }

        private string confPath = "";
        public int port { get; set; }
        public int max_thread_cnt { get; set; }
        public string category { get; set; }

        public string private_key { get; set; }
        public string dh_iv { get; set; }

        public RSAParameters privateParam;

        private ServerConf(JObject _json, string _path)
            : base(_json)
        {
            confPath = _path;
            //읽어온 설정값을 통한 초기화 작업
            Init();
        }

        private void Init()
        {
            //rsa private key 생성해야하는 경우.
            if (private_key == "")
            {
                var csp = new RSACryptoServiceProvider();

                //생성된 public key client에게 적용할 것.
                var publicParam = csp.ExportParameters(false);
                {
                    var sw = new StringWriter();
                    var xs = new XmlSerializer(typeof(RSAParameters));
                    xs.Serialize(sw, publicParam);
                    string public_key = sw.ToString();
                }

                var privateParam = csp.ExportParameters(true);
                {
                    var sw = new StringWriter();
                    var xs = new XmlSerializer(typeof(RSAParameters));
                    xs.Serialize(sw, privateParam);
                    private_key = sw.ToString();
                }
                if (confPath != string.Empty)
                {
                    using (var ws = new StreamWriter(confPath, false, Encoding.UTF8))
                    {
                        JObject jobj = GetJObjectFromProperties();
                        string jsonStr = jobj.ToString();
                        ws.Write(jsonStr);
                        ws.Flush();
                    }
                }
            }

            using (var sr = new StringReader(private_key))
            {
                var xs = new XmlSerializer(typeof(RSAParameters));
                privateParam = (RSAParameters)xs.Deserialize(sr);
            }
        }
    }
}
