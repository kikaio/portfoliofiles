﻿using CoreNet.Networking;
using CoreNet.Utils.Loggers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TcpAsyncCommon_TAP.Packets
{

    public class PacketFactory
    {
        private Dictionary<Packet.PACKET_TYPE, Dictionary<Packet.CONTENT_TYPE, Func<Packet, Packet>>> FactoryDict
            = new Dictionary<Packet.PACKET_TYPE, Dictionary<Packet.CONTENT_TYPE, Func<Packet, Packet>>>();

        private static PacketFactory inst = new PacketFactory();
        public static PacketFactory Inst
        {
            get
            {
                return inst;
            }
        }
        private CoreLogger logger = new ConsoleLogger();
        private PacketFactory()
        {
            Init();
        }

        private void Init()
        {
            //packet 은 반드시 packet type, contents type을 읽은상태로 가정한다.
            foreach (Packet.PACKET_TYPE _enum in Enum.GetValues(typeof(Packet.PACKET_TYPE)))
            {
                FactoryDict.Add(_enum, new Dictionary<Packet.CONTENT_TYPE, Func<Packet, Packet>>());
                var subDict = FactoryDict[_enum];
                switch (_enum)
                {
                    case Packet.PACKET_TYPE.REQ:
                        subDict[Packet.CONTENT_TYPE.CHATTING] = (_p) =>
                        {
                            var ret = new PacketChat_Req(_p);
                            ret.SerialRead();
                            return ret;
                        };
                        subDict[Packet.CONTENT_TYPE.SIGN_IN] = (_p) =>
                        {
                            var ret = new PacketSignIn_Req(_p);
                            ret.SerialRead();
                            return ret;
                        };
                        subDict[Packet.CONTENT_TYPE.SIGN_OUT] = (_p) =>
                        {
                            var ret = new PacketSignOut_Req(_p);
                            ret.SerialRead();
                            return ret;
                        };
                        subDict[Packet.CONTENT_TYPE.LOG_IN] = (_p) =>
                        {
                            var ret = new PacketLogIn_Req(_p);
                            ret.SerialRead();
                            return ret;
                        };
                        subDict[Packet.CONTENT_TYPE.LOG_OUT] = (_p) =>
                        {
                            var ret = new PacketLogOut_Req(_p);
                            ret.SerialRead();
                            return ret;
                        };

                        break;
                    case Packet.PACKET_TYPE.ANS:
                        subDict[Packet.CONTENT_TYPE.WELCOME] = (_p) =>
                        {
                            var ret = new PacketWelcome(_p);
                            ret.SerialRead();
                            return ret;
                        };
                        subDict[Packet.CONTENT_TYPE.CHATTING] = (_p) =>
                        {
                            var ret = new PacketChat_Ans(_p);
                            ret.SerialRead();
                            return ret;
                        };
                        subDict[Packet.CONTENT_TYPE.SIGN_IN] = (_p) =>
                        {
                            var ret = new PacketSignIn_Ans(_p);
                            ret.SerialRead();
                            return ret;
                        };
                        subDict[Packet.CONTENT_TYPE.SIGN_OUT] = (_p) =>
                        {
                            var ret = new PacketSignOut_Ans(_p);
                            ret.SerialRead();
                            return ret;
                        };
                        subDict[Packet.CONTENT_TYPE.LOG_IN] = (_p) =>
                        {
                            var ret = new PacketLogIn_Ans(_p);
                            ret.SerialRead();
                            return ret;
                        };
                        subDict[Packet.CONTENT_TYPE.LOG_OUT] = (_p) =>
                        {
                            var ret = new PacketLogOut_Ans(_p);
                            ret.SerialRead();
                            return ret;
                        };
                        break;
                    case Packet.PACKET_TYPE.NOTI:
                        subDict[Packet.CONTENT_TYPE.HB_CHECK] = (_p) =>
                        {
                            var ret = new PacketHbCheck_Noti(_p);
                            ret.SerialRead();
                            return ret;
                        };
                        break;
                    case Packet.PACKET_TYPE.TEST:
                        subDict[Packet.CONTENT_TYPE.TEST] = (_p) =>
                        {
                            var ret = new PacketTester(_p);
                            ret.SerialRead();
                            return ret;
                        };
                        break;
                    default:
                        break;
                }
            }
        }

        public T ConvertPacket<T>(Packet _p) where T : Packet
        {
            var ret = default(T);
            var pType = _p.pType;
            var cType = _p.cType;
            if (FactoryDict.ContainsKey(pType) == false || FactoryDict[pType].ContainsKey(cType) == false)
                logger.Error($"not registed in packetFactory -> {pType}-{cType}");
            else
                ret = (T)FactoryDict[_p.pType][_p.cType](_p);
            return ret;
        }
    }
}
